import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// Helper to convert File to Base64
export const fileToGenerativePart = async (file: File) => {
  return new Promise<{ inlineData: { data: string; mimeType: string } }>((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64Data = (reader.result as string).split(',')[1];
      resolve({
        inlineData: {
          data: base64Data,
          mimeType: file.type,
        },
      });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

export const getNearbyLandmarks = async (lat: number, lon: number) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: "Identify 3 key landmarks, famous places, or main roads very close to this location. Return ONLY the names as a comma-separated list.",
      config: {
        tools: [{ googleMaps: {} }],
        toolConfig: {
          retrievalConfig: {
            latLng: {
              latitude: lat,
              longitude: lon
            }
          }
        }
      }
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Maps Error:", error);
    return null;
  }
};

export const analyzeAccident = async (description: string, imageFiles: File[]) => {
  try {
    const parts: any[] = [];
    
    // Add text prompt
    parts.push({
      text: `You are an expert crane operator assistant for 'Sogarwal Crane Service'. 
      Analyze the following accident situation based on the user's description and images (if provided).
      
      User Description: "${description}"

      Provide a structured JSON response with:
      1. "estimatedSeverity": "Low" | "Medium" | "High" | "Critical"
      2. "recommendedCraneType": Short description of the crane needed (e.g. "Small Tow Truck", "Hydraulic 40 Ton", "Heavy Recovery Unit")
      3. "safetyTips": A list of 3 immediate safety actions for the user.
      4. "estimatedTime": A rough estimate of setup time (e.g. "30 mins").
      
      Output ONLY raw JSON.`
    });

    // Add images
    for (const file of imageFiles) {
      const imagePart = await fileToGenerativePart(file);
      parts.push(imagePart);
    }

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts },
      config: {
        responseMimeType: "application/json"
      }
    });

    return JSON.parse(response.text);

  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return {
      estimatedSeverity: "Unknown",
      recommendedCraneType: "Standard Tow Truck",
      safetyTips: ["Stay clear of traffic", "Turn on hazard lights", "Do not stand near the vehicle"],
      estimatedTime: "Unknown"
    };
  }
};