import React, { useState } from 'react';
import { User } from '../types';

interface LoginProps {
  onLogin: (user: User) => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      setStep(2);
    }, 1500);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onLogin({ phoneNumber: phone, isVerified: true });
    }, 1500);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-brand-black px-4 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 left-0 w-full h-1/2 bg-brand-yellow/10 -skew-y-6 transform origin-top-left"></div>
      
      <div className="relative z-10 w-full max-w-md bg-brand-dark p-8 rounded-2xl border border-gray-800 shadow-2xl">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-brand-yellow rounded-full mx-auto flex items-center justify-center text-3xl mb-4">
             <i className="fa-solid fa-user-lock text-black"></i>
          </div>
          <h2 className="text-2xl font-display font-bold text-white uppercase">Client Login</h2>
          <p className="text-gray-400 text-sm">Access your service history and quick requests</p>
        </div>

        {step === 1 ? (
          <form onSubmit={handleSendOtp}>
            <div className="mb-6">
              <label className="block text-xs uppercase text-gray-500 mb-2">Mobile Number</label>
              <div className="flex bg-black rounded border border-gray-700 overflow-hidden">
                <div className="bg-gray-800 px-3 py-3 text-gray-400 border-r border-gray-700">+91</div>
                <input 
                  type="tel" 
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="flex-1 bg-transparent px-4 py-3 text-white focus:outline-none"
                  placeholder="98765 43210"
                  required
                />
              </div>
            </div>
            <button 
              type="submit" 
              disabled={loading}
              className="w-full bg-brand-yellow text-black font-bold py-3 rounded hover:bg-white transition-colors flex justify-center items-center"
            >
              {loading ? <i className="fa-solid fa-circle-notch fa-spin"></i> : "SEND OTP"}
            </button>
          </form>
        ) : (
          <form onSubmit={handleVerifyOtp}>
             <div className="mb-6 text-center">
              <p className="text-gray-400 text-sm mb-4">Enter the code sent to <span className="text-white">+91 {phone}</span></p>
              <div className="flex justify-center space-x-2">
                {[1, 2, 3, 4].map((_, i) => (
                  <input
                    key={i}
                    type="text"
                    maxLength={1}
                    className="w-12 h-12 text-center text-2xl font-bold bg-black border border-gray-700 rounded text-brand-yellow focus:border-brand-yellow focus:outline-none"
                    value={otp[i] || ''}
                    onChange={(e) => {
                      const val = e.target.value;
                      const newOtp = otp.split('');
                      newOtp[i] = val;
                      setOtp(newOtp.join(''));
                      if(val && e.target.nextElementSibling) {
                        (e.target.nextElementSibling as HTMLElement).focus();
                      }
                    }}
                  />
                ))}
              </div>
            </div>
            <button 
              type="submit" 
              disabled={loading || otp.length < 4}
              className="w-full bg-brand-yellow text-black font-bold py-3 rounded hover:bg-white transition-colors flex justify-center items-center"
            >
               {loading ? <i className="fa-solid fa-circle-notch fa-spin"></i> : "VERIFY & LOGIN"}
            </button>
            <button 
              type="button" 
              onClick={() => setStep(1)} 
              className="w-full mt-4 text-gray-500 text-sm hover:text-white"
            >
              Change Number
            </button>
          </form>
        )}
      </div>
    </div>
  );
};