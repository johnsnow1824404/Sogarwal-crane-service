
import React, { useState, useEffect, useRef } from 'react';
import { AppView } from '../types';
import { SERVICES } from '../constants';
import { TiltCard } from '../components/UI/TiltCard';

interface HomeProps {
  setView: (view: AppView) => void;
}

export const Home: React.FC<HomeProps> = ({ setView }) => {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  
  // Parallax Effect Logic
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      // Normalize mouse position from -1 to 1
      const x = (e.clientX / window.innerWidth) * 2 - 1;
      const y = (e.clientY / window.innerHeight) * 2 - 1;
      setMousePos({ x, y });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white overflow-hidden perspective-2000">
      
      {/* --- HERO SECTION: 3D PARALLAX SCENE --- */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        
        {/* Layer 0: Deep Background (Moves slowly) */}
        <div 
          className="absolute inset-0 pointer-events-none"
          style={{ transform: `translate(${mousePos.x * -10}px, ${mousePos.y * -10}px) scale(1.1)` }}
        >
           <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-gray-900 via-black to-black opacity-80"></div>
           <div className="absolute top-0 right-0 w-[60vw] h-[60vw] bg-brand-yellow/5 rounded-full blur-[150px]"></div>
           <div className="absolute bottom-0 left-0 w-[50vw] h-[50vw] bg-yellow-900/10 rounded-full blur-[120px]"></div>
           <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay"></div>
        </div>

        {/* Layer 1: Giant Text (Moves slightly) */}
        <div 
          className="absolute inset-0 flex items-center justify-center pointer-events-none z-0"
          style={{ transform: `translate(${mousePos.x * -20}px, ${mousePos.y * -20}px)` }}
        >
           <h1 className="text-[12vw] font-display font-bold text-transparent bg-clip-text bg-gradient-to-b from-gray-800 to-black leading-none select-none opacity-40">
             HEAVY<br/>LIFTING
           </h1>
        </div>

        {/* Layer 2: Main Content (The "Stage") */}
        <div className="container mx-auto px-6 relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center h-full">
          
          {/* Text Content */}
          <div 
             className="lg:col-span-5 space-y-8 transform transition-transform duration-200 ease-out"
             style={{ transform: `translate(${mousePos.x * 10}px, ${mousePos.y * 10}px)` }}
          >
             <div className="inline-block">
               <div className="flex items-center gap-3 px-4 py-2 bg-white/5 border border-white/10 backdrop-blur-md rounded-full">
                 <span className="relative flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-yellow opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-brand-yellow"></span>
                 </span>
                 <span className="text-xs font-bold tracking-[0.2em] text-brand-yellow uppercase">24/7 Emergency Active</span>
               </div>
             </div>
             
             <h2 className="text-6xl md:text-7xl lg:text-8xl font-display font-bold leading-[0.9] text-white drop-shadow-2xl">
                SOGARWAL<br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-yellow to-yellow-600">CRANE</span>
             </h2>

             <p className="text-lg text-gray-400 max-w-md font-light border-l-2 border-brand-yellow pl-4">
               Premium breakdown recovery and heavy lifting services. 
               <br/>AI-Driven. GPS-Tracked. Fast.
             </p>

             <div className="flex gap-4 pt-4">
                <button 
                  onClick={() => setView(AppView.EMERGENCY)}
                  className="group relative px-8 py-4 bg-brand-yellow text-black font-bold uppercase tracking-widest overflow-hidden rounded-sm"
                >
                  <div className="absolute inset-0 w-full h-full bg-white/50 transform -translate-x-full skew-x-12 transition-transform duration-500 group-hover:translate-x-full"></div>
                  <span className="relative flex items-center gap-2">
                    Request Now <i className="fa-solid fa-arrow-right group-hover:translate-x-1 transition-transform"></i>
                  </span>
                </button>
                <button 
                   onClick={() => setView(AppView.SERVICES)}
                   className="px-8 py-4 border border-white/20 text-white font-bold uppercase tracking-widest hover:bg-white/10 hover:border-brand-yellow transition-all rounded-sm backdrop-blur-sm"
                >
                   View Fleet
                </button>
             </div>
          </div>

          {/* 3D Visual - Floating Card */}
          <div className="lg:col-span-7 flex justify-center lg:justify-end relative">
             <TiltCard depth={40} className="w-full max-w-md lg:max-w-xl aspect-[4/5] relative z-20">
                <div className="relative w-full h-full rounded-2xl overflow-hidden border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.5)] bg-[#111] group">
                   
                   {/* Card Background */}
                   <img 
                     src="https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&q=80&w=1000" 
                     alt="Heavy Crane"
                     className="absolute inset-0 w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-110 transition-all duration-700 ease-out grayscale hover:grayscale-0"
                   />
                   
                   {/* Overlay Elements inside 3D Card */}
                   <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-90"></div>
                   
                   {/* Floating UI Elements inside Card (Parallax) */}
                   <div className="absolute bottom-8 left-8 right-8 transform translate-z-20 transition-transform">
                      <div className="flex justify-between items-end border-b border-white/20 pb-4 mb-4">
                         <div>
                            <p className="text-brand-yellow text-xs font-bold uppercase tracking-widest mb-1">Heavy Duty</p>
                            <h3 className="text-3xl font-display font-bold">50 TON</h3>
                         </div>
                         <div className="text-right">
                            <p className="text-xs text-gray-400 uppercase">Status</p>
                            <p className="text-green-400 font-bold flex items-center gap-1">
                               <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span> READY
                            </p>
                         </div>
                      </div>
                      <div className="flex items-center gap-4 text-xs font-mono text-gray-400">
                         <span><i className="fa-solid fa-location-dot"></i> BHARATPUR HQ</span>
                         <span><i className="fa-solid fa-clock"></i> <span className="text-white">24/7</span></span>
                      </div>
                   </div>

                   {/* Tech Details Overlay */}
                   <div className="absolute top-8 right-8 flex flex-col items-end gap-2">
                      <div className="w-16 h-16 border border-brand-yellow/30 rounded-full flex items-center justify-center bg-black/50 backdrop-blur-md animate-spin-slow">
                         <i className="fa-solid fa-gear text-brand-yellow/50 text-xl"></i>
                      </div>
                      <span className="text-[10px] text-brand-yellow font-mono tracking-widest">SOGARWAL.SYS.01</span>
                   </div>

                </div>
             </TiltCard>
          </div>

        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 flex flex-col items-center gap-2 opacity-50 animate-bounce">
           <span className="text-[10px] uppercase tracking-[0.3em]">Scroll</span>
           <i className="fa-solid fa-chevron-down text-brand-yellow"></i>
        </div>
      </section>


      {/* --- SERVICES SECTION: STAGGERED GRID --- */}
      <section className="relative py-32 bg-[#0a0a0a]">
         <div className="container mx-auto px-6">
            <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-6">
               <div className="transform transition-all duration-1000 opacity-0 animate-[slideUp_1s_ease-out_0.5s_forwards]">
                  <h2 className="text-4xl md:text-6xl font-display font-bold text-white leading-none">
                     OUR <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-yellow to-white">FLEET</span>
                  </h2>
                  <p className="mt-4 text-gray-400 max-w-lg">
                     A diverse range of heavy recovery vehicles equipped for any scenario, from highway breakdowns to industrial shifting.
                  </p>
               </div>
               <button 
                  onClick={() => setView(AppView.SERVICES)}
                  className="text-brand-yellow font-bold uppercase tracking-widest text-sm hover:text-white transition-colors flex items-center gap-2"
               >
                  View All Services <i className="fa-solid fa-arrow-right"></i>
               </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
               {SERVICES.map((service, index) => (
                  <div key={service.id} className="opacity-0 animate-[slideUp_0.8s_ease-out_forwards]" style={{ animationDelay: `${0.2 * index}s` }}>
                     <TiltCard depth={15} className="h-full">
                        <div 
                           className="h-full bg-white/5 border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all duration-500 group cursor-pointer relative overflow-hidden backdrop-blur-sm"
                           onClick={() => setView(AppView.SERVICES)}
                        >
                           {/* Hover Gradient */}
                           <div className="absolute inset-0 bg-gradient-to-br from-brand-yellow/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                           <div className="relative z-10">
                              <div className="w-14 h-14 bg-black/50 rounded-xl border border-white/10 flex items-center justify-center mb-6 group-hover:border-brand-yellow/50 transition-colors shadow-lg">
                                 <i className={`fa-solid ${service.icon} text-2xl text-white group-hover:text-brand-yellow transition-colors`}></i>
                              </div>
                              
                              <h3 className="text-xl font-display font-bold mb-3">{service.title}</h3>
                              <p className="text-sm text-gray-400 leading-relaxed mb-6 group-hover:text-gray-300">
                                 {service.description}
                              </p>

                              <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
                                 <div className="h-full bg-brand-yellow w-0 group-hover:w-full transition-all duration-700 ease-out"></div>
                              </div>
                           </div>
                        </div>
                     </TiltCard>
                  </div>
               ))}
            </div>
         </div>
      </section>


      {/* --- TRUST BADGES: 3D FLOATING ELEMENTS --- */}
      <section className="py-24 relative overflow-hidden bg-gradient-to-b from-[#0a0a0a] to-[#111]">
         {/* Background Grid */}
         <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:50px_50px]"></div>
         
         <div className="container mx-auto px-6 relative z-10">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
               {[
                  { icon: 'fa-clock', title: '30 Min Response', desc: 'Fastest arrival time in Bharatpur region.' },
                  { icon: 'fa-shield-halved', title: 'Fully Insured', desc: 'Your vehicle safety is our top priority.' },
                  { icon: 'fa-sack-dollar', title: 'Fair Pricing', desc: 'Transparent quotes generated by AI.' }
               ].map((item, i) => (
                  <div key={i} className="flex flex-col items-center text-center animate-float" style={{ animationDelay: `${i * 1.5}s` }}>
                     <div className="w-24 h-24 rounded-full bg-gradient-to-br from-gray-800 to-black border border-white/10 shadow-[0_10px_30px_rgba(0,0,0,0.5)] flex items-center justify-center mb-6 relative group">
                        <div className="absolute inset-0 rounded-full bg-brand-yellow/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                        <i className={`fa-solid ${item.icon} text-3xl text-brand-yellow transform group-hover:scale-110 transition-transform`}></i>
                     </div>
                     <h3 className="text-xl font-bold font-display uppercase tracking-wider mb-2">{item.title}</h3>
                     <p className="text-gray-500 text-sm max-w-xs">{item.desc}</p>
                  </div>
               ))}
            </div>
         </div>
      </section>

      {/* --- CTA SECTION --- */}
      <section className="py-32 relative">
         <div className="absolute inset-0 overflow-hidden">
            <img 
               src="https://images.unsplash.com/photo-1517523217961-d70c4b726194?auto=format&fit=crop&q=80&w=2000" 
               alt="Background" 
               className="w-full h-full object-cover opacity-20 grayscale"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/80 to-transparent"></div>
         </div>

         <div className="container mx-auto px-6 relative z-10 text-center">
            <h2 className="text-5xl md:text-7xl font-display font-bold mb-8">
               STUCK ON THE ROAD?
            </h2>
            <p className="text-xl text-gray-300 mb-12 max-w-2xl mx-auto">
               Don't panic. Our AI-powered system will locate you and dispatch the nearest crane immediately.
            </p>
            <div className="flex justify-center">
               <button 
                  onClick={() => setView(AppView.EMERGENCY)}
                  className="px-12 py-6 bg-brand-yellow text-black text-xl font-bold uppercase tracking-widest rounded shadow-[0_0_50px_rgba(255,215,0,0.4)] hover:shadow-[0_0_80px_rgba(255,215,0,0.6)] hover:scale-105 transition-all transform animate-pulse-fast"
               >
                  <i className="fa-solid fa-phone mr-3"></i> Get Help Now
               </button>
            </div>
         </div>
      </section>

    </div>
  );
};
