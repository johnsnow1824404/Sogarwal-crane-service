
import React, { useRef, useState, MouseEvent } from 'react';

interface TiltCardProps {
  children: React.ReactNode;
  className?: string;
  depth?: number;
  glare?: boolean;
}

export const TiltCard: React.FC<TiltCardProps> = ({ children, className = '', depth = 20, glare = true }) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const [scale, setScale] = useState(1);
  const [glarePos, setGlarePos] = useState({ x: 50, y: 50 });
  const [opacity, setOpacity] = useState(0);

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;

    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    // Calculate rotation based on cursor position
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    
    const rotateXValue = ((y - centerY) / centerY) * -depth; // Invert Y for natural feel
    const rotateYValue = ((x - centerX) / centerX) * depth;

    setRotateX(rotateXValue);
    setRotateY(rotateYValue);

    // Calculate Glare Position (percentage)
    const glareX = (x / rect.width) * 100;
    const glareY = (y / rect.height) * 100;
    setGlarePos({ x: glareX, y: glareY });
  };

  const handleMouseEnter = () => {
    setScale(1.05);
    setOpacity(1);
  };

  const handleMouseLeave = () => {
    setRotateX(0);
    setRotateY(0);
    setScale(1);
    setOpacity(0);
  };

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      className={`transition-transform duration-200 ease-out transform-style-3d relative ${className}`}
      style={{
        transform: `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(${scale}, ${scale}, ${scale})`,
      }}
    >
      {/* Content */}
      <div className="transform-style-3d">
        {children}
      </div>

      {/* Dynamic Glare Layer */}
      {glare && (
        <div 
          className="absolute inset-0 w-full h-full rounded-inherit pointer-events-none z-50 transition-opacity duration-300"
          style={{
            opacity: opacity,
            background: `radial-gradient(circle at ${glarePos.x}% ${glarePos.y}%, rgba(255,255,255,0.3) 0%, rgba(255,255,255,0) 80%)`,
            mixBlendMode: 'overlay',
          }}
        />
      )}
    </div>
  );
};
