import React, { useState } from 'react';
import { LocationPicker } from './LocationPicker';
import { PhotoUploader } from './PhotoUploader';
import { LocationData } from '../../types';
import { analyzeAccident } from '../../services/gemini';
import { CONTACT_WHATSAPP } from '../../constants';

export const EmergencyForm: React.FC = () => {
  const [step, setStep] = useState(1);
  const [location, setLocation] = useState<LocationData>({ latitude: null, longitude: null, address: '', loading: false, error: null });
  const [photos, setPhotos] = useState<File[]>([]);
  const [description, setDescription] = useState('');
  const [vehicleType, setVehicleType] = useState('Car');
  const [phone, setPhone] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<any>(null);

  const handleAnalyze = async () => {
    if (!description && photos.length === 0) return;
    setIsAnalyzing(true);
    const result = await analyzeAccident(description, photos);
    setAiAnalysis(result);
    setIsAnalyzing(false);
    setStep(2); // Move to review step
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Construct WhatsApp Message
    const text = `
🚨 *EMERGENCY CRANE REQUEST* 🚨
---------------------------
📍 *Location:* ${location.address || 'Shared via Map'}
(Lat: ${location.latitude}, Lon: ${location.longitude})

📱 *Phone:* ${phone}
🚙 *Vehicle:* ${vehicleType}
📝 *Note:* ${description}

🤖 *AI Assessment:*
- Severity: ${aiAnalysis?.estimatedSeverity || 'N/A'}
- Recommended: ${aiAnalysis?.recommendedCraneType || 'N/A'}
---------------------------
    `.trim();

    const encodedText = encodeURIComponent(text);
    window.open(`https://wa.me/${CONTACT_WHATSAPP}?text=${encodedText}`, '_blank');
  };

  return (
    <div className="max-w-xl mx-auto">
      <div className="bg-brand-black border border-yellow-600 rounded-2xl overflow-hidden shadow-2xl">
        <div className="bg-gradient-to-r from-yellow-600 to-yellow-500 p-4">
           <h2 className="text-black font-display font-bold text-2xl uppercase tracking-tighter flex items-center">
             <i className="fa-solid fa-triangle-exclamation mr-3 animate-pulse"></i>
             Emergency Request
           </h2>
           <p className="text-black/80 text-sm font-bold">Fastest Response Guarantee in Bharatpur</p>
        </div>

        <form onSubmit={handleSubmit} className="p-6">
          
          {/* Step 1: Gather Info */}
          {step === 1 && (
            <>
              <LocationPicker locationData={location} setLocationData={setLocation} />
              
              {/* Phone Number - PROMINENTLY PLACED BEFORE PHOTOS */}
              <div className="mb-6 p-4 bg-gray-900 border-l-4 border-brand-yellow rounded">
                 <label className="text-sm text-brand-yellow font-bold uppercase tracking-wider block mb-2">
                    Enter Contact Number <span className="text-red-500">*</span>
                 </label>
                 <div className="flex items-center">
                    <span className="bg-gray-800 text-white p-3 rounded-l border-y border-l border-gray-600 font-mono">+91</span>
                    <input 
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="95871 61624"
                        className="w-full bg-brand-dark text-white font-bold text-xl p-3 rounded-r border border-gray-600 focus:border-brand-yellow focus:outline-none"
                        required
                    />
                 </div>
                 <p className="text-[10px] text-gray-400 mt-1">We will call this number for location coordination.</p>
              </div>

              <div className="mb-6">
                <label className="text-xs text-gray-400 uppercase tracking-wider block mb-2">Vehicle Type</label>
                <div className="grid grid-cols-3 gap-2">
                  {['Car', 'SUV', 'Truck', 'Bus', 'Bike', 'Heavy'].map(type => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setVehicleType(type)}
                      className={`py-2 px-1 text-sm rounded border ${vehicleType === type ? 'bg-brand-yellow text-black border-brand-yellow font-bold' : 'border-gray-700 text-gray-400 hover:border-gray-500'}`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              <PhotoUploader photos={photos} setPhotos={setPhotos} />

              <div className="mb-6">
                <label className="text-xs text-gray-400 uppercase tracking-wider block mb-1">Situation Description</label>
                <textarea 
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="E.g. Car slipped into ditch, stuck in mud, engine failure..."
                  className="w-full bg-brand-dark border border-brand-grey rounded p-3 text-white focus:border-brand-yellow h-24"
                />
              </div>

              <button
                type="button"
                onClick={handleAnalyze}
                disabled={isAnalyzing || !phone || (!description && photos.length === 0)}
                className="w-full bg-gradient-to-r from-gray-800 to-gray-900 border border-gray-600 text-white font-bold py-4 rounded-lg relative overflow-hidden group disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isAnalyzing ? (
                   <span className="flex items-center justify-center space-x-2">
                     <i className="fa-solid fa-circle-notch fa-spin text-brand-yellow"></i>
                     <span>AI Analyzing Scene...</span>
                   </span>
                ) : (
                   <span className="flex items-center justify-center space-x-2 group-hover:scale-105 transition-transform">
                     <i className="fa-solid fa-robot text-brand-yellow"></i>
                     <span>Next: Get AI Estimate</span>
                   </span>
                )}
              </button>
            </>
          )}

          {/* Step 2: Review & Send */}
          {step === 2 && (
            <div className="animate-fade-in">
              <h3 className="text-brand-yellow font-display text-xl mb-4 uppercase">Assessment Report</h3>
              
              {aiAnalysis && (
                <div className="bg-gray-800/50 p-4 rounded-lg mb-6 border-l-4 border-brand-yellow">
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-400 text-xs uppercase">Severity</span>
                    <span className={`font-bold text-sm ${aiAnalysis.estimatedSeverity === 'Critical' ? 'text-red-500' : 'text-white'}`}>
                      {aiAnalysis.estimatedSeverity}
                    </span>
                  </div>
                  <div className="mb-2">
                    <span className="text-gray-400 text-xs uppercase block mb-1">Recommended Crane</span>
                    <span className="text-brand-yellow font-bold text-lg">{aiAnalysis.recommendedCraneType}</span>
                  </div>
                  <div className="mb-2">
                    <span className="text-gray-400 text-xs uppercase block mb-1">Safety Tips</span>
                    <ul className="text-sm text-gray-300 list-disc pl-4 space-y-1">
                      {aiAnalysis.safetyTips.map((tip: string, i: number) => (
                        <li key={i}>{tip}</li>
                      ))}
                    </ul>
                  </div>
                  <div className="mt-4 pt-4 border-t border-gray-700">
                    <span className="text-gray-400 text-xs uppercase">Est. Arrival Time</span>
                    <span className="text-white font-bold ml-2">{aiAnalysis.estimatedTime || "30-45 mins"}</span>
                  </div>
                </div>
              )}

              <div className="bg-brand-dark p-3 rounded mb-6 flex justify-between items-center">
                 <span className="text-gray-400 text-sm">Contact Number:</span>
                 <span className="text-white font-bold font-mono">{phone}</span>
              </div>

              <div className="flex space-x-3">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="flex-1 py-3 border border-gray-600 rounded text-gray-400 hover:text-white"
                >
                  Edit
                </button>
                <button
                  type="submit"
                  className="flex-[2] bg-green-600 hover:bg-green-500 text-white font-bold py-3 rounded flex items-center justify-center space-x-2 shadow-lg shadow-green-900/50"
                >
                  <i className="fa-brands fa-whatsapp text-xl"></i>
                  <span>REQUEST NOW</span>
                </button>
              </div>
            </div>
          )}

        </form>
      </div>
    </div>
  );
};