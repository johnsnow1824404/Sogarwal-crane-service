import React, { useState, useEffect } from 'react';
import { LocationData } from '../../types';
import { getNearbyLandmarks } from '../../services/gemini';

interface LocationPickerProps {
  locationData: LocationData;
  setLocationData: (data: LocationData) => void;
}

export const LocationPicker: React.FC<LocationPickerProps> = ({ locationData, setLocationData }) => {
  const [mapUrl, setMapUrl] = useState<string>('');
  const [nearbyLandmarks, setNearbyLandmarks] = useState<string | null>(null);
  const [findingLandmarks, setFindingLandmarks] = useState(false);

  const fetchAddressAndLandmarks = async (lat: number, lon: number) => {
    // 1. Fetch Basic Address
    try {
      const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}`);
      const data = await res.json();
      
      let addressStr = `Lat: ${lat.toFixed(6)}, Lon: ${lon.toFixed(6)}`;
      if (data && data.display_name) {
        addressStr = data.display_name;
      }
      
      setLocationData({
        ...locationData,
        latitude: lat,
        longitude: lon,
        address: addressStr,
        loading: false,
      });
    } catch (e) {
      setLocationData({
        ...locationData,
        latitude: lat,
        longitude: lon,
        address: `Lat: ${lat.toFixed(6)}, Lon: ${lon.toFixed(6)}`,
        loading: false,
      });
    }

    // 2. Fetch Famous Landmarks via Gemini (Grounding)
    setFindingLandmarks(true);
    const landmarks = await getNearbyLandmarks(lat, lon);
    if (landmarks) {
      setNearbyLandmarks(landmarks);
    }
    setFindingLandmarks(false);
  };

  const handleGetLocation = () => {
    setLocationData({ ...locationData, loading: true, error: null });
    setNearbyLandmarks(null);

    if (!navigator.geolocation) {
      setLocationData({ ...locationData, loading: false, error: "Geolocation is not supported by your browser." });
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setMapUrl(`https://static-maps.yandex.ru/1.x/?lang=en-US&ll=${longitude},${latitude}&z=16&l=map&size=600,400&pt=${longitude},${latitude},pm2rdm`);
        fetchAddressAndLandmarks(latitude, longitude);
      },
      (error) => {
        setLocationData({ ...locationData, loading: false, error: "Unable to retrieve your location. Please enable GPS." });
      },
      { enableHighAccuracy: true }
    );
  };

  return (
    <div className="bg-brand-dark p-4 rounded-xl border border-brand-grey mb-6 shadow-lg">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-white font-bold flex items-center text-lg">
          <i className="fa-solid fa-map-location-dot text-brand-yellow mr-3"></i>
          Incident Location
        </h3>
        {locationData.loading && <span className="text-xs text-brand-yellow animate-pulse font-mono">LOCATING...</span>}
      </div>

      {/* Map Container - Increased Size */}
      <div className="relative h-64 md:h-80 bg-gray-800 rounded-lg overflow-hidden mb-4 border border-gray-600 group shadow-inner">
        {locationData.latitude ? (
           <div className="w-full h-full relative">
              {/* Using a generic map background that looks 'zoomed in' to simulate detail */}
              <img 
                src="https://images.unsplash.com/photo-1569336415962-a4bd9f69cd83?auto=format&fit=crop&q=80&w=1000"
                alt="Map Detail" 
                className="w-full h-full object-cover opacity-50 contrast-125"
              />
              {/* Overlay Grid */}
              <div className="absolute inset-0 bg-[linear-gradient(rgba(0,255,0,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,0,0.1)_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none"></div>
              
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
                 <div className="w-4 h-4 bg-red-500 rounded-full animate-ping absolute"></div>
                 <i className="fa-solid fa-location-dot text-5xl text-red-500 drop-shadow-[0_4px_6px_rgba(0,0,0,0.8)] z-10"></i>
                 <div className="bg-black/80 text-brand-yellow text-xs font-bold px-2 py-1 rounded mt-2 border border-brand-yellow/50 whitespace-nowrap">
                   EXACT LOCATION PINNED
                 </div>
              </div>
           </div>
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center text-gray-500 bg-gray-900">
            <i className="fa-solid fa-satellite-dish text-5xl mb-4 opacity-30"></i>
            <p className="text-sm font-mono uppercase tracking-wider">Waiting for GPS Signal</p>
          </div>
        )}
      </div>

      {/* Address & Context */}
      <div className="space-y-3 mb-4">
        <div>
          <label className="text-xs text-brand-yellow font-bold uppercase tracking-wider block mb-1">Detected Address</label>
          <div className="w-full bg-black/50 border border-brand-grey rounded p-3 text-sm text-white h-auto min-h-[3rem]">
            {locationData.address || "Location not detected yet"}
          </div>
        </div>

        {/* Nearby Landmarks - Gemini Powered */}
        {(nearbyLandmarks || findingLandmarks) && (
          <div className="bg-gray-800/50 p-3 rounded border-l-2 border-blue-500">
            <label className="text-[10px] text-blue-400 font-bold uppercase tracking-wider block mb-1">
              <i className="fa-solid fa-landmark mr-1"></i> Nearby Famous Places (Auto-Detected)
            </label>
            {findingLandmarks ? (
               <div className="text-xs text-gray-400 animate-pulse">Scanning nearby landmarks...</div>
            ) : (
               <div className="text-xs text-white leading-relaxed font-medium">
                 {nearbyLandmarks}
               </div>
            )}
          </div>
        )}
      </div>

      <button
        type="button"
        onClick={handleGetLocation}
        className="w-full bg-brand-yellow text-brand-black font-bold py-4 rounded uppercase tracking-wider hover:bg-white transition-colors flex items-center justify-center space-x-2 shadow-lg shadow-yellow-900/20"
      >
        <i className="fa-solid fa-crosshairs animate-[spin_3s_linear_infinite_paused] hover:animate-spin"></i>
        <span>Share Live Location & Find Landmarks</span>
      </button>
      
      {locationData.error && <p className="text-red-500 text-xs mt-2 text-center bg-red-900/20 p-2 rounded">{locationData.error}</p>}
    </div>
  );
};