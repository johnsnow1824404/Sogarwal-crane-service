import React, { useRef } from 'react';

interface PhotoUploaderProps {
  photos: File[];
  setPhotos: (files: File[]) => void;
}

export const PhotoUploader: React.FC<PhotoUploaderProps> = ({ photos, setPhotos }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setPhotos([...photos, ...newFiles]);
    }
  };

  const removePhoto = (index: number) => {
    const newPhotos = [...photos];
    newPhotos.splice(index, 1);
    setPhotos(newPhotos);
  };

  return (
    <div className="bg-brand-dark p-4 rounded-xl border border-brand-grey mb-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-white font-bold flex items-center">
          <i className="fa-solid fa-camera text-brand-yellow mr-2"></i>
          Upload Photos
        </h3>
        <span className="text-xs text-gray-400">For Quick Estimate</span>
      </div>

      <div className="grid grid-cols-3 gap-2 mb-4">
        {photos.map((file, idx) => (
          <div key={idx} className="relative aspect-square rounded overflow-hidden border border-gray-600 group">
            <img 
              src={URL.createObjectURL(file)} 
              alt="preview" 
              className="w-full h-full object-cover" 
            />
            <button
              onClick={() => removePhoto(idx)}
              className="absolute top-1 right-1 bg-red-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs"
            >
              <i className="fa-solid fa-times"></i>
            </button>
          </div>
        ))}
        
        <button 
          onClick={() => fileInputRef.current?.click()}
          className="aspect-square rounded border-2 border-dashed border-gray-600 flex flex-col items-center justify-center text-gray-500 hover:text-brand-yellow hover:border-brand-yellow transition-colors"
        >
          <i className="fa-solid fa-plus text-2xl mb-1"></i>
          <span className="text-[10px] uppercase">Add Photo</span>
        </button>
      </div>

      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileChange} 
        className="hidden" 
        multiple 
        accept="image/*"
      />
    </div>
  );
};