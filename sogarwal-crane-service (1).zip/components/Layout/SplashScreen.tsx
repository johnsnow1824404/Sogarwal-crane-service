import React, { useEffect, useState } from 'react';
import { SPLASH_SEQUENCE } from '../../constants';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [sceneIndex, setSceneIndex] = useState(0);
  const [showText, setShowText] = useState(false);

  useEffect(() => {
    // Total duration: approx 8 seconds
    // Scene 0: Boom Lift Simulation (0s - 3s)
    // Scene 1: Orbit Rotation Simulation (3s - 6s)
    // Scene 2: Final Reveal (6s - 8s)

    const timer1 = setTimeout(() => {
      setSceneIndex(1);
    }, 3000);

    const timerText = setTimeout(() => {
      setShowText(true);
    }, 500);

    const timer2 = setTimeout(() => {
      setSceneIndex(2);
    }, 6000);

    const timerEnd = setTimeout(() => {
      onComplete();
    }, 8000);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timerText);
      clearTimeout(timer2);
      clearTimeout(timerEnd);
    };
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-[100] bg-black overflow-hidden flex items-center justify-center perspective-1000">
      
      {/* SCENE 1: BOOM LIFT SIMULATION */}
      {/* Image translates upwards while zooming out to simulate lifting */}
      <div 
        className={`absolute inset-0 transition-opacity duration-1000 ${sceneIndex === 0 ? 'opacity-100' : 'opacity-0'}`}
      >
        <img 
          src={SPLASH_SEQUENCE[0]} 
          alt="Boom Lift" 
          className="w-full h-full object-cover industrial-filter animate-boom-lift origin-bottom"
        />
        {/* Soft Spotlight effect */}
        <div className="absolute inset-0 bg-gradient-to-tr from-black/80 via-transparent to-brand-yellow/10 mix-blend-overlay"></div>
      </div>

      {/* SCENE 2: ORBIT SIMULATION */}
      {/* Image rotates slightly and pans to simulate drone orbit */}
      <div 
        className={`absolute inset-0 transition-opacity duration-1000 ${sceneIndex === 1 ? 'opacity-100' : 'opacity-0'}`}
      >
        <img 
          src={SPLASH_SEQUENCE[1]} 
          alt="Crane Orbit" 
          className="w-full h-full object-cover industrial-filter animate-crane-orbit origin-center"
        />
        <div className="absolute inset-0 bg-gradient-to-tl from-black/80 via-transparent to-brand-yellow/10 mix-blend-overlay"></div>
      </div>

      {/* SCENE 3: FINAL CINEMATIC ZOOM */}
      <div 
        className={`absolute inset-0 transition-opacity duration-1000 ${sceneIndex === 2 ? 'opacity-100' : 'opacity-0'}`}
      >
        <img 
          src={SPLASH_SEQUENCE[2]} 
          alt="Final Reveal" 
          className="w-full h-full object-cover industrial-filter animate-cinematic-zoom"
        />
      </div>

      {/* GLOBAL VIGNETTE & GRAIN */}
      <div className="absolute inset-0 vignette pointer-events-none"></div>
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 pointer-events-none mix-blend-overlay"></div>

      {/* TEXT OVERLAY LAYER */}
      <div className="absolute inset-0 z-20 flex flex-col items-center justify-center pointer-events-none">
        <div className={`transition-all duration-1000 transform ${showText ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 translate-y-10 scale-90'}`}>
           
           {/* Main Title with Glow */}
           <div className="text-center mb-2 px-4">
              <h1 className="font-display text-5xl md:text-7xl font-bold text-transparent bg-clip-text bg-gradient-to-b from-brand-yellow to-yellow-600 animate-text-glow leading-none drop-shadow-2xl">
                SOGARWAL
              </h1>
              <h2 className="font-display text-3xl md:text-5xl font-bold text-white tracking-[0.2em] mt-2 drop-shadow-lg">
                CRANE SERVICE
              </h2>
           </div>

           {/* Location Tag */}
           <div className="flex items-center justify-center space-x-4 mt-6 opacity-0 animate-[fadeIn_1s_ease-out_1.5s_forwards]">
              <div className="h-[2px] w-16 bg-brand-yellow shadow-[0_0_10px_#FFD700]"></div>
              <span className="font-sans font-bold text-xl md:text-2xl text-brand-yellow tracking-[0.3em] uppercase drop-shadow-md">
                BHARATPUR
              </span>
              <div className="h-[2px] w-16 bg-brand-yellow shadow-[0_0_10px_#FFD700]"></div>
           </div>

        </div>
      </div>
      
      {/* Loading Progress Bar (Bottom) */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-900">
        <div className="h-full bg-brand-yellow shadow-[0_0_15px_#FFD700] animate-[width_8s_linear_forwards]" style={{ width: '0%' }}></div>
      </div>

    </div>
  );
};