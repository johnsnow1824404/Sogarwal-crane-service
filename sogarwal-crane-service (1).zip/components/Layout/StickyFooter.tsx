import React from 'react';
import { CONTACT_PHONE, CONTACT_WHATSAPP } from '../../constants';
import { AppView } from '../../types';

interface StickyFooterProps {
  onEmergencyClick: () => void;
}

export const StickyFooter: React.FC<StickyFooterProps> = ({ onEmergencyClick }) => {
  return (
    <div className="fixed bottom-0 left-0 w-full z-40 bg-brand-black border-t border-brand-yellow/50 shadow-2xl shadow-brand-yellow/20 pb-safe">
      <div className="grid grid-cols-3 h-16">
        
        {/* WhatsApp */}
        <a 
          href={`https://wa.me/${CONTACT_WHATSAPP}`}
          target="_blank"
          rel="noreferrer"
          className="flex flex-col items-center justify-center bg-green-700 hover:bg-green-600 text-white transition-colors"
        >
          <i className="fa-brands fa-whatsapp text-2xl mb-1"></i>
          <span className="text-[10px] uppercase font-bold tracking-wider">WhatsApp</span>
        </a>

        {/* Emergency Center Button */}
        <button
          onClick={onEmergencyClick}
          className="relative -top-6 flex flex-col items-center justify-center"
        >
          <div className="w-20 h-20 rounded-full bg-brand-yellow border-4 border-brand-black flex items-center justify-center shadow-lg shadow-brand-yellow/50 animate-pulse-fast">
             <i className="fa-solid fa-truck-medical text-3xl text-black"></i>
          </div>
          <span className="mt-1 text-xs font-bold text-brand-yellow uppercase tracking-widest bg-brand-black px-2 py-0.5 rounded">SOS NOW</span>
        </button>

        {/* Call Now */}
        <a 
          href={`tel:${CONTACT_PHONE}`}
          className="flex flex-col items-center justify-center bg-blue-700 hover:bg-blue-600 text-white transition-colors"
        >
          <i className="fa-solid fa-phone text-2xl mb-1"></i>
          <span className="text-[10px] uppercase font-bold tracking-wider">Call Now</span>
        </a>

      </div>
    </div>
  );
};