import React, { useEffect, useRef } from 'react';

export const CursorEffect: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particles = useRef<any[]>([]);
  const cursor = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();

    const handleMouseMove = (e: MouseEvent) => {
      cursor.current.x = e.clientX;
      cursor.current.y = e.clientY;

      // Create multiple particles for a "spark" effect
      for (let i = 0; i < 3; i++) {
        particles.current.push(createParticle(e.clientX, e.clientY));
      }
    };

    window.addEventListener('mousemove', handleMouseMove);

    const createParticle = (x: number, y: number) => {
      return {
        x,
        y,
        size: Math.random() * 3 + 1, // Random size
        speedX: Math.random() * 2 - 1, // Random drift X
        speedY: Math.random() * 2 - 1, // Random drift Y
        life: 100, // 100% life
        color: Math.random() > 0.5 ? '#FFD700' : '#FFA500', // Gold or Orange
      };
    };

    const animate = () => {
      if (!ctx || !canvas) return;

      // Clear with a slight fade effect for trails
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Update and draw particles
      for (let i = 0; i < particles.current.length; i++) {
        const p = particles.current[i];
        
        // Move particle
        p.x += p.speedX;
        p.y += p.speedY;
        
        // Shrink and fade
        p.life -= 2;
        p.size -= 0.05;

        if (p.life > 0 && p.size > 0) {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fillStyle = p.color;
          // Add glow
          ctx.shadowBlur = 10;
          ctx.shadowColor = p.color;
          ctx.globalAlpha = p.life / 100;
          ctx.fill();
          ctx.globalAlpha = 1;
          ctx.shadowBlur = 0;
        } else {
          particles.current.splice(i, 1);
          i--;
        }
      }

      requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-[60] mix-blend-screen"
      style={{ width: '100vw', height: '100vh' }}
    />
  );
};