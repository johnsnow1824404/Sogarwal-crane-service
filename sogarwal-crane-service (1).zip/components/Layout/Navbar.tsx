
import React, { useState, useEffect } from 'react';
import { AppView } from '../../types';

interface NavbarProps {
  currentView: AppView;
  setView: (view: AppView) => void;
  userPhone: string | null;
}

export const Navbar: React.FC<NavbarProps> = ({ currentView, setView, userPhone }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Home', view: AppView.HOME },
    { label: 'Services', view: AppView.SERVICES },
    { label: 'Gallery', view: AppView.GALLERY },
    { label: 'Contact', view: AppView.CONTACT },
  ];

  return (
    <nav 
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        scrolled ? 'py-2 bg-black/80 backdrop-blur-md shadow-lg border-b border-white/10' : 'py-6 bg-transparent'
      }`}
    >
      <div className="container mx-auto px-6 flex justify-between items-center">
        {/* Logo */}
        <div 
          className="flex items-center gap-3 cursor-pointer group"
          onClick={() => setView(AppView.HOME)}
        >
          <div className="relative">
            <div className="absolute inset-0 bg-brand-yellow blur-md opacity-20 group-hover:opacity-50 transition-opacity"></div>
            <i className="fa-solid fa-truck-monster text-brand-yellow text-2xl relative z-10"></i>
          </div>
          <div className="flex flex-col">
            <span className="font-display font-bold text-xl tracking-widest text-white leading-none">SOGARWAL</span>
            <span className="text-[0.6rem] text-brand-yellow tracking-[0.4em] uppercase opacity-80">Crane Service</span>
          </div>
        </div>

        {/* Desktop Menu - Minimalist */}
        <div className="hidden md:flex items-center space-x-8">
          {navItems.map((item) => (
            <button
              key={item.label}
              onClick={() => setView(item.view)}
              className={`relative text-sm font-medium uppercase tracking-widest transition-all hover:text-brand-yellow ${
                currentView === item.view ? 'text-brand-yellow' : 'text-gray-300'
              } group`}
            >
              {item.label}
              <span className={`absolute -bottom-1 left-0 w-0 h-0.5 bg-brand-yellow transition-all duration-300 group-hover:w-full ${currentView === item.view ? 'w-full' : ''}`}></span>
            </button>
          ))}
          {userPhone && (
             <div className="px-3 py-1 rounded-full border border-white/20 text-xs text-brand-yellow font-mono">
                {userPhone}
             </div>
          )}
        </div>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden text-white hover:text-brand-yellow transition-colors"
          onClick={() => setIsOpen(!isOpen)}
        >
          <i className={`fa-solid ${isOpen ? 'fa-times' : 'fa-bars-staggered'} text-2xl`}></i>
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      <div className={`fixed inset-0 bg-black/95 z-40 transition-transform duration-300 md:hidden flex items-center justify-center ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="flex flex-col space-y-8 text-center">
            {navItems.map((item) => (
              <button
                key={item.label}
                onClick={() => {
                  setView(item.view);
                  setIsOpen(false);
                }}
                className={`text-3xl font-display font-bold uppercase tracking-wider ${
                  currentView === item.view ? 'text-brand-yellow' : 'text-white/50'
                }`}
              >
                {item.label}
              </button>
            ))}
             <button onClick={() => setIsOpen(false)} className="mt-8 text-sm text-gray-500 uppercase tracking-widest">Close Menu</button>
        </div>
      </div>
    </nav>
  );
};
